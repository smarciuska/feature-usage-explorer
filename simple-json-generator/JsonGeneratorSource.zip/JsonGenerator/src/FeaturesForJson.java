import java.util.ArrayList;

public class FeaturesForJson {
	int id;
	int pid;
	String name;
	String usage;
	String type;
	ArrayList<Links> linksOut;
	ArrayList<Links> linksIn;

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsage() {
		return usage;
	}

	public void setUsage(String usage) {
		this.usage = usage;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ArrayList<Links> getLinksOut() {
		return linksOut;
	}

	public void setLinksOut(ArrayList<Links> linksOut) {
		this.linksOut = linksOut;
	}

	public ArrayList<Links> getLinksIn() {
		return linksIn;
	}

	public void setLinksIn(ArrayList<Links> linksIn) {
		this.linksIn = linksIn;
	}

}
