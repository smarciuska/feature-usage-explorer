import java.util.Date;

public class Feature implements Comparable<Feature>{

	Date time;
	String name;

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int compareTo(Feature f) {
		return getTime().compareTo(f.getTime());
	}

}
