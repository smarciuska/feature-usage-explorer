import javax.swing.*;

import com.google.gson.Gson;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;

public class Generator extends JPanel implements ActionListener {
	private static final long serialVersionUID = -2634100826152554344L;
	private String newline = "\n";
	protected JTextArea input;
	protected JButton button;
	protected JTextPane output;

	public Generator() {
		setLayout(new BorderLayout());

		// Create a text area with a set of input data.
		input = new JTextArea("11-04-17; Feature 1" + newline
				+ "11-05-08; Feature 1" + newline + "11-05-08; Feature 2"
				+ newline + "11-05-09; Feature 1"
				+newline+ "11-04-17; Feature 3");

		JScrollPane areaScrollPane = new JScrollPane(input);
		areaScrollPane
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		areaScrollPane.setPreferredSize(new Dimension(350, 250));
		areaScrollPane
				.setBorder(BorderFactory.createCompoundBorder(
						BorderFactory.createCompoundBorder(
								BorderFactory
										.createTitledBorder("Input Usage Data: dd-mm-yy; Feature Name"),
								BorderFactory.createEmptyBorder(5, 5, 5, 5)),
						areaScrollPane.getBorder()));

		// Create a text pane.
		output = new JTextPane();
		JScrollPane textScrollPane = new JScrollPane(output);
		textScrollPane
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		textScrollPane.setPreferredSize(new Dimension(350, 250));
		textScrollPane.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createCompoundBorder(
						BorderFactory.createTitledBorder("Output json file:"),
						BorderFactory.createEmptyBorder(5, 5, 5, 5)),
				textScrollPane.getBorder()));

		// Put everything together.
		JPanel leftPane = new JPanel(new BorderLayout());
		leftPane.add(areaScrollPane, BorderLayout.CENTER);

		JPanel rightPane = new JPanel(new BorderLayout());
		rightPane.add(textScrollPane, BorderLayout.CENTER);

		button = new JButton("Generate json");
		button.addActionListener(this);

		add(leftPane, BorderLayout.LINE_START);
		add(rightPane, BorderLayout.LINE_END);
		add(button, BorderLayout.PAGE_END);
	}

	private static void createAndShowGUI() {
		JFrame frame = new JFrame("json generator");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new Generator());
		frame.pack();
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		/*--First we read all the input information and sort the features by date--*/
		ArrayList<Feature> features = new ArrayList<Feature>();
		DateFormat formatter = new SimpleDateFormat("dd-mm-yy");
		for (String line : input.getText().split("\\n")) {
			String[] info = line.split(";");
			Feature f = new Feature();
			f.setName(info[1]);
			try {
				f.setTime(formatter.parse(info[0]));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			features.add(f);
		}
		Collections.sort(features);
		String outputText = "";
		for (Feature f : features) {
			outputText += formatter.format(f.getTime()) + ";" + f.getName()
					+ newline;
		}
		input.setText(outputText);

		ArrayList<FeaturesForJson> json = new ArrayList<FeaturesForJson>();
		HashSet<String> featureNames = new HashSet<String>();
		featureNames = getFeatures(features);

		Hashtable<String, Integer> namesToIds = new Hashtable<String, Integer>();

		int ids = 1;
		for (String name : featureNames) {
			namesToIds.put(name, ids);
			ids++;
		}

		int id = 1;
		for (String name : featureNames) {

			FeaturesForJson jsonFeature = new FeaturesForJson();
			jsonFeature.setId(id);
			jsonFeature.setName(name);
			jsonFeature.setUsage(getUsage(features, name));
			jsonFeature.setType("feature");
			jsonFeature.setLinksIn(getLinksIn(features, name, namesToIds));
			jsonFeature.setLinksOut(getLinksOut(features, name, namesToIds));
			if (id > 1){
				jsonFeature.setPid(getPid(jsonFeature));
			}
			json.add(jsonFeature);
			id++;
		}
		Gson gson = new Gson();
		output.setText(gson.toJson(json));
		/*--END--*/
	}

	private int getPid(FeaturesForJson jsonFeature) {
		int pid = Integer.MAX_VALUE;
		ArrayList<Links> out = jsonFeature.getLinksOut();
		ArrayList<Links> in = jsonFeature.getLinksIn();
		for (Links link: out){
			if(pid>link.getId())
			pid = link.getId();
		}
		for (Links link: in){
			if(pid>link.getId())
				pid = link.getId();
		}
		if (pid!=Integer.MAX_VALUE){
			return pid;
		}
		return 0;
	}

	private HashSet<String> getFeatures(ArrayList<Feature> features) {
		HashSet<String> uniqueNames = new HashSet<String>();
		for (Feature feature : features)
			uniqueNames.add(feature.getName());
		return uniqueNames;
	}

	private String getUsage(ArrayList<Feature> features, String name) {
		int usage = 0;
		for (Feature feature : features)
			if (feature.getName().equals(name))
				usage++;
		return String.valueOf(usage);
	}

	private ArrayList<Links> getLinksOut(ArrayList<Feature> features,
			String name, Hashtable<String, Integer> namesToIds) {
		Hashtable<String, Integer> linksIn = new Hashtable<String, Integer>();
		for (int i = 0; i < features.size(); i++) {
			if ((i + 1 < features.size())
					&& features.get(i).getName().equals(name)
					&& !features.get(i + 1).getName().equals(name)) {
				if (linksIn.containsKey(features.get(i + 1).getName())) {
					linksIn.put(features.get(i + 1).getName(),
							linksIn.get(features.get(i + 1).getName()) + 1);
				} else {
					linksIn.put(features.get(i + 1).getName(), 1);
				}
			}
		}
		Set<String> keys = linksIn.keySet();

		ArrayList<Links> links = new ArrayList<Links>();

		for (String key : keys) {
			Integer val = linksIn.get(key);
			Links link = new Links();
			link.setId(namesToIds.get(key));
			link.setCardinality(val.toString());
			links.add(link);
		}
		return links;
	}

	private ArrayList<Links> getLinksIn(ArrayList<Feature> features,
			String name, Hashtable<String, Integer> namesToIds) {
		Hashtable<String, Integer> linksIn = new Hashtable<String, Integer>();
		for (int i = 0; i < features.size(); i++) {
			if ((i + 1 < features.size())
					&& features.get(i + 1).getName().equals(name)
					&& !features.get(i).getName().equals(name)) {
				if (linksIn.containsKey(features.get(i).getName())) {
					linksIn.put(features.get(i).getName(),
							linksIn.get(features.get(i).getName()) + 1);
				} else {
					linksIn.put(features.get(i).getName(), 1);
				}
			}
		}
		Set<String> keys = linksIn.keySet();

		ArrayList<Links> links = new ArrayList<Links>();

		for (String key : keys) {
			Integer val = linksIn.get(key);
			Links link = new Links();
			link.setId(namesToIds.get(key));
			link.setCardinality(val.toString());
			links.add(link);
		}
		return links;
	}

}
